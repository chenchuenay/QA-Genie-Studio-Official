import 'package:qa_genie/engine/models/pipeline_models.dart';
import 'package:qa_genie/engine/recovery/deterministic_case_generator.dart';

class PartialSuiteExpander {
  final DeterministicCaseGenerator deterministicGenerator;

  PartialSuiteExpander({required this.deterministicGenerator});

  /// Expands a partial suite by generating missing cases from a list of required outcomes.
  List<WorkingCase> expand({
    required List<WorkingCase> existingCases,
    required List<String> missingOutcomes,
    required GenerationRequest request,
  }) {
    if (missingOutcomes.isEmpty) return existingCases;

    // Create a temporary request that asks only for the missing outcomes.
    // Since we have specific outcomes, we can use generateByOutcomes (new method)
    final generated = deterministicGenerator.generateByOutcomes(
      request: request,
      outcomes: missingOutcomes,
    );
    return [...existingCases, ...generated];
  }
}
