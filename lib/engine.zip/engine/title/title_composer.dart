import 'package:qa_genie/engine/business/business_area.dart';

class TitleComposer {
  static String compose({
    required String outcome,
    required BusinessArea businessArea,
    required String feature,
    required String primaryObservation,
  }) {
    final action = _actionFromOutcome(outcome);
    final subject = _subjectFromBusinessArea(businessArea);
    final obs = _observationSummary(primaryObservation);
    return 'Verify $action $subject $obs';
  }

  static String _actionFromOutcome(String outcome) {
    if (outcome.contains('login')) return 'authentication';
    if (outcome.contains('transfer')) return 'money transfer';
    if (outcome.contains('checkout')) return 'checkout';
    return outcome.replaceAll('_', ' ');
  }

  static String _subjectFromBusinessArea(BusinessArea area) {
    switch (area.id) {
      case 'authentication':
        return 'user';
      case 'ecommerce':
        return 'order';
      case 'banking':
        return 'transaction';
      default:
        return 'process';
    }
  }

  static String _observationSummary(String observation) {
    final words = observation.split(' ');
    final short = words.take(6).join(' ');
    return short.length < observation.length ? '$short ...' : short;
  }
}
