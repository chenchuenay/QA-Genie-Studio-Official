import 'package:qa_genie/engine/business/business_area.dart';
import 'package:qa_genie/engine/observations/observation_generator.dart';

class ExpectedResultComposer {
  static String compose({
    required String outcome,
    required BusinessArea businessArea,
    required List<String> observations,
    required String platform,
    required String feature,
  }) {
    final outcomePhrase = _outcomeToPhrase(outcome);
    final businessEffect = _businessEffect(businessArea, outcome, feature);
    final allParts = <String>[];
    allParts.add(outcomePhrase);
    allParts.addAll(observations);
    if (businessEffect.isNotEmpty) allParts.add(businessEffect);
    return allParts.join(' ');
  }

  static String _outcomeToPhrase(String outcome) {
    switch (outcome) {
      case 'valid_login':
        return 'Authentication request is accepted.';
      case 'social_login':
        return 'OAuth login flow completes successfully.';
      case 'invalid_password':
        return 'Authentication is rejected.';
      default:
        return 'Operation completes.';
    }
  }

  static String _businessEffect(
    BusinessArea area,
    String outcome,
    String feature,
  ) {
    if (area.id == 'authentication') {
      if (outcome.contains('valid') ||
          outcome.contains('social') ||
          outcome.contains('mfa')) {
        return 'User can access $feature features and protected resources.';
      } else {
        return 'User remains unable to access $feature.';
      }
    } else if (area.id == 'ecommerce') {
      if (outcome == 'valid_checkout') {
        return 'Order is placed and confirmation is sent.';
      } else {
        return 'Order is not placed, cart remains unchanged.';
      }
    }
    return '';
  }
}
