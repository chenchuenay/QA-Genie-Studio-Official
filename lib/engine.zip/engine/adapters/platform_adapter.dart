import 'package:qa_genie/domain/entities/test_step.dart';

enum StepAction {
  navigate,
  input,
  select,
  submit,
  wait,
  verify,
  request,
  validate,
  session,
  security,
}

enum EntityType {
  entryPoint,
  credentialForm,
  actionButton,
  successIndicator,
  errorMessage,
  sessionToken,
  dashboard,
  order,
  receipt,
  item,
  amount,
  recoveryField,
  confirmation,
  timeout,
  sessionStatus,
  oauthProvider,
  oauthConsent,
  callback,
  otpCode,
  priceValidation,
}

class WorkflowNode {
  final StepAction action;
  final EntityType entity;
  final String? dataKey;

  const WorkflowNode({
    required this.action,
    required this.entity,
    this.dataKey,
  });
}

abstract class PlatformAdapter {
  List<TestStep> toSteps(
    List<WorkflowNode> nodes,
    Map<String, dynamic> testData,
  );
}

class ApiAdapter implements PlatformAdapter {
  @override
  List<TestStep> toSteps(
    List<WorkflowNode> nodes,
    Map<String, dynamic> testData,
  ) {
    final steps = <TestStep>[];
    for (final node in nodes) {
      final (action, data, expected) = _resolve(node, testData);
      steps.add(TestStep(action: action, data: data, expected: expected));
    }
    return steps;
  }

  (String, String, String) _resolve(
    WorkflowNode node,
    Map<String, dynamic> testData,
  ) {
    switch (node.action) {
      case StepAction.navigate:
        return ('Send request to endpoint', '', 'HTTP 200 OK');
      case StepAction.input:
        if (node.entity == EntityType.credentialForm) {
          final email = testData['email'] ?? '';
          final password = testData['password'] ?? '';
          return (
            'Send login request',
            'email=$email&password=$password',
            'HTTP 200 OK',
          );
        }
        return ('Send request with data', testData.toString(), 'HTTP 200 OK');
      case StepAction.select:
        if (node.entity == EntityType.oauthProvider) {
          final provider = testData['provider'] ?? 'unknown';
          return (
            'Set OAuth provider',
            'provider=$provider',
            'HTTP 302 Redirect',
          );
        }
        return (
          'Select option',
          testData[node.dataKey ?? 'value']?.toString() ?? '',
          'Request accepted',
        );
      case StepAction.submit:
        if (node.entity == EntityType.actionButton)
          return ('Submit request', '', 'HTTP 200 OK');
        if (node.entity == EntityType.oauthConsent)
          return ('Grant consent', '', 'HTTP 302 with callback');
        return ('Execute action', '', 'HTTP 200 OK');
      case StepAction.wait:
        if (node.entity == EntityType.callback)
          return ('Wait for callback', '', 'Callback received');
        if (node.entity == EntityType.timeout)
          return ('Wait for timeout', '', 'Session expires');
        return ('Wait', '', 'Operation completes');
      case StepAction.verify:
        if (node.entity == EntityType.successIndicator)
          return ('Verify success', '', 'Success confirmed');
        if (node.entity == EntityType.sessionToken)
          return ('Verify session token', '', 'Token is valid');
        if (node.entity == EntityType.errorMessage)
          return ('Verify error', '', 'Error message displayed');
        return ('Verify outcome', '', 'Expected condition met');
      default:
        return ('Perform action', '', 'Action completes');
    }
  }
}

class WebAdapter implements PlatformAdapter {
  @override
  List<TestStep> toSteps(
    List<WorkflowNode> nodes,
    Map<String, dynamic> testData,
  ) {
    final steps = <TestStep>[];
    for (final node in nodes) {
      final (action, data, expected) = _resolve(node, testData);
      steps.add(TestStep(action: action, data: data, expected: expected));
    }
    return steps;
  }

  (String, String, String) _resolve(
    WorkflowNode node,
    Map<String, dynamic> testData,
  ) {
    switch (node.action) {
      case StepAction.navigate:
        return ('Open page', '', 'Page loads successfully');
      case StepAction.input:
        if (node.entity == EntityType.credentialForm) {
          final email = testData['email'] ?? '';
          final password = testData['password'] ?? '';
          return (
            'Enter credentials',
            '$email / $password',
            'Input fields accept data',
          );
        }
        return (
          'Enter data',
          testData[node.dataKey ?? 'value']?.toString() ?? '',
          'Input accepted',
        );
      case StepAction.select:
        if (node.entity == EntityType.oauthProvider) {
          final provider = testData['provider'] ?? 'unknown';
          return (
            'Click Sign in with $provider',
            '',
            'Redirect to provider consent screen',
          );
        }
        return (
          'Select option',
          testData[node.dataKey ?? 'value']?.toString() ?? '',
          'Selection confirmed',
        );
      case StepAction.submit:
        if (node.entity == EntityType.actionButton)
          return ('Click button', '', 'Action submitted');
        if (node.entity == EntityType.oauthConsent)
          return ('Approve consent', '', 'Redirect back to app');
        return ('Submit form', '', 'Submission processed');
      case StepAction.wait:
        return ('Wait', '', 'Wait completes');
      case StepAction.verify:
        if (node.entity == EntityType.successIndicator)
          return ('Verify success', '', 'Success message appears');
        if (node.entity == EntityType.sessionToken)
          return ('Verify session', '', 'Session cookie is set');
        if (node.entity == EntityType.errorMessage)
          return ('Verify error', '', 'Error message visible');
        return ('Verify outcome', '', 'Expected condition met');
      default:
        return ('Perform action', '', 'Action completes');
    }
  }
}
